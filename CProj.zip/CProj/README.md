# CProj — Constitutional Project, Fifth Pass

This repository hosts the fifth-pass architecture of the constitutional theory
project. Its current active task is execution-plan authoring for the
remaining twenty-eight documents of the thirty-seven-document arc.

## Start Here

1. Read `CLAUDE.md` — it specifies the authoring task, plan structure, drift-
   check protocol, and ambiguity escalation policy that Claude Code follows
   in this repo.
2. Read `Claude_Code_Kickoff_Prompt.md` — paste its contents into Claude
   Code as the kickoff message.
3. Read `project/Fifth_Pass_Planning_Document.md` Section II to see the
   thirty-seven-document arc.

## Repository Layout

```
CProj/
├── CLAUDE.md                              # Authoring rules for Claude Code
├── Claude_Code_Kickoff_Prompt.md          # Paste-in kickoff message
├── README.md                              # This file
├── .gitignore
├── project/
│   ├── Fifth_Pass_Planning_Document.md    # Single source of truth (fifth pass)
│   ├── Fourth_Pass_Planning_Document.md   # Historical reference
│   ├── bibliography_consolidated_v4.md
│   ├── question_resolution_answers.md
│   ├── exemplar_plans/                    # Phase α plans — calibration anchors
│   │   ├── Execution_Plan_Document_1.md
│   │   ├── Execution_Plan_Document_2.md
│   │   └── Execution_Plan_Document_3.md
│   └── source_documents/                  # Fourth-pass drafts + foundational texts
│       ├── v5_completed/                  # Phase α outputs (Documents 1, 2, 3 v5)
│       └── [fourth-pass source files]
└── outputs/                               # Claude Code writes here
    └── [Execution_Plan_Document_*.md as authored]
```

## Workflow

- **Phase α is complete.** Documents 1, 2, and 3 have v5 outputs in
  `project/source_documents/v5_completed/`. Their execution plans (the
  calibration anchors for everything that follows) live in
  `project/exemplar_plans/`.
- **Phases β through ι** — execution plans are authored in this repo by
  Claude Code per the strict phase order in CLAUDE.md.
- **Documents M, W, R** — stubs only in this repo; full plans authored
  separately in claude.ai.
- **Drafting** of the actual documents happens in claude.ai, one document
  per session, using the authored execution plans as self-contained prompts.

## Phase Status

| Phase | Documents | Status |
|-------|-----------|--------|
| α     | 1, 2, 3   | Complete (plans + v5 drafts done) |
| β     | A, 4, B, C, I | Pending |
| γ     | M*, K, L  | Pending (*M is stub-only) |
| δ     | N, O, P, Q | Pending |
| ε     | S, T, U, V, W*, 7, 8, 9, 10 | Pending (*W is stub-only) |
| ζ     | E, F, H, J | Pending |
| η     | R*, D-1, D-2, D-3, D-4 | Pending (*R is stub-only) |
| θ     | D-Synthesis | Pending (claude.ai) |
| ι     | G          | Pending |
| κ     | (cleanup pass) | Pending |
